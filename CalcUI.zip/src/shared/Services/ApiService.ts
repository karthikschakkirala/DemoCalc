import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpClient: HttpClient) { }

    PostAPI(data: any) {
        const headers = new HttpHeaders({
            'Authorization': 'Negotiate',
            'Content-Type': 'application/json',
            // 'Access-Control-Allow-Origin': '*',
            // 'Access-Control-Allow-Credentials': 'true',
            // 'Access-Control-Allow-Headers': 'Content-Type',
            // 'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE',
        });
        
        return this.httpClient.post('https://localhost:44306/api/calculate/sum', JSON.stringify(data), { headers, withCredentials: true });
    }
}