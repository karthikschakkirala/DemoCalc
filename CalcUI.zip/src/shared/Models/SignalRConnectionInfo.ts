export class SignalRConnectionInfo {
  url: string;
  accessKey: string;
  userId: string;
  idToken: string;
}