export class CalcModel {
    NoOne: BigInt;
    NoTwo: BigInt;
  }