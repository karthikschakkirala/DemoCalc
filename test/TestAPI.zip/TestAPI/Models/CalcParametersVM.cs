﻿namespace TestAPI.Models
{
    public class CalcParametersVM
    {
        public string NoOne { get; set; }
        public string NoTwo { get; set; }
    }
}
