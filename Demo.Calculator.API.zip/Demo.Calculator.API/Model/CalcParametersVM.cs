﻿namespace Demo.Calculator.API.Model
{
    public class CalcParametersVM
    {
        public int NoOne { get; set; }
        public int NoTwo { get; set; }
    }
}
