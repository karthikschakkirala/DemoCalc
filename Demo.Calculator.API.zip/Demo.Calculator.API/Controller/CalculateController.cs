﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using System.Text;
using System;
using Demo.Calculator.API.Model;
using Microsoft.AspNetCore.Cors;

namespace Demo.Calculator.API.Controller
{
    [Route("api/calculate")]
    [ApiController]
    [Authorize]
    [EnableCors("ApiCorsPolicy")]
    public class CalculateController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly string ServiceBusConnectionString;
        private readonly string TopicName;

        static ITopicClient topicClient;

        public CalculateController(IConfiguration configuration)
        {
            _configuration = configuration.GetSection("AppSettings");
            ServiceBusConnectionString = _configuration["ServiceBusConnectionString"];
            TopicName = _configuration["TopicName"];
        }

        [Route("sum")]
        [HttpPost]
        public async Task<IActionResult> Sum(CalcParametersVM calcParameters)
        {
            int total = calcParameters.NoOne + calcParameters.NoTwo;
            await SendMessageAsync("Sum of two is: " + total);
            return Ok(new
            {
                Success = true,
                StatusCode = 200
            });
        }

        private async Task SendMessageAsync(string messageBody)
        {
            topicClient = new TopicClient(ServiceBusConnectionString, TopicName);

            var message = new Message(Encoding.UTF8.GetBytes(messageBody));
            await topicClient.SendAsync(message);

            await topicClient.CloseAsync();
        }
    }
}
